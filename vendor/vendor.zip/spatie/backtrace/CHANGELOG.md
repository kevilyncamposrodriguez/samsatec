# Changelog

All notable changes to `backtrace` will be documented in this file

## 1.2.1 - 2021-11-09

- Add a return typehint (#4)

## 1.2.0 - 2021-05-19

- add `firstApplicationFrameIndex`

## 1.1.0 - 2021-01-29

- add `snippetProperties`

## 1.0.1 - 2021-01-27

- add support for PHP 7.3

## 1.0.0 - 2020-11-24

- initial release
