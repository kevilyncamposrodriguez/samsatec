<?php

namespace Reedware\LaravelRelationJoins\Tests\Models;

class EloquentLikeModelStub extends EloquentRelationJoinModelStub
{
    protected $table = 'likes';
}
