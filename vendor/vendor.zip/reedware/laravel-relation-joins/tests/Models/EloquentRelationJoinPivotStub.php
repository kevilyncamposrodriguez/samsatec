<?php

namespace Reedware\LaravelRelationJoins\Tests\Models;

use Illuminate\Database\Eloquent\Relations\Pivot;

class EloquentRelationJoinPivotStub extends Pivot
{
    //
}
